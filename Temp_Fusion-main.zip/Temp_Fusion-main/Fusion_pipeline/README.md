To run the code:
```bash
CUDA_VISIBLE_DEVICES=0 python3 main.py --inp_dir <path_to_generated_input> --out_dir <path_to_generated_output>
```
To replicate this, 
```bash
# conda create --name <env> --file requirements.txt
conda activate test1
```
